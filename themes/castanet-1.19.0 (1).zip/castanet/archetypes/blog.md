+++
Description = ""
Date = {{ .Date }}
PublishDate = {{ .Date }} # this is the datetime for the when the epsiode was published. This will default to Date if it is not set. Example is "2016-04-25T04:09:45-05:00"
title = ""
#blog_banner = ""
blog_image = "img/episode/default.jpg"
images = ["img/episode/default-social.jpg"]
#Author = ""
#aliases = ["/##"]
+++
